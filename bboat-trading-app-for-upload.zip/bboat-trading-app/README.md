# BBoat Trading App

A Streamlit-based gold trading analysis tool integrated with TradingView and IC Markets. This version is ready for upload to GitHub from your mobile phone.

## Features

- Gold strategy analyzer (RSI, Bollinger Bands, Breakout)
- Auto trading script for IC Markets via MetaTrader 5
- Daily timeframe focus using TradingView data
- Secure login
- Mobile-ready via Streamlit Cloud

## Run locally

```bash
streamlit run frontend/app.py
```
