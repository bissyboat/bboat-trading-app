# Script for auto trading via MT5
print('Auto-trading logic here')