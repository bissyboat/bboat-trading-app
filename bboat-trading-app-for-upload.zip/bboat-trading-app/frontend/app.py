# Streamlit app main entry point
import streamlit as st
st.title('BBoat Trading App')